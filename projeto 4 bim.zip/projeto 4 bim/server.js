const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'crud_funcionarios'
});

// Listar funcionários
app.get('/api/funcionarios', async (req, res) => {
    const [dados] = await db.execute(
        'SELECT * FROM funcionarios'
    );

    res.json(dados);
});

// Cadastrar funcionário
app.post('/api/funcionarios', async (req, res) => {
    const { nome, funcao, salario } = req.body;

    await db.execute(
        'INSERT INTO funcionarios (nome, funcao, salario) VALUES (?, ?, ?)',
        [nome, funcao, salario]
    );

    res.json({ mensagem: 'Cadastro realizado!' });
});

app.listen(3306, () => {
    console.log('Servidor rodando na porta 3000');
});