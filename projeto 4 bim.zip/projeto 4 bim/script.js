const API = 'http://localhost:3000/api/funcionarios';

async function cadastrar() {
    const nome = document.getElementById('nome').value;
    const funcao = document.getElementById('funcao').value;
    const salario = document.getElementById('salario').value;

    if (!nome || !funcao || !salario) {
        alert('Preencha todos os campos!');
        return;
    }

    await fetch(API, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            nome: nome,
            funcao: funcao,
            salario: salario
        })
    });

    alert('Funcionário cadastrado!');
    listar();
}

async function listar() {
    const resposta = await fetch(API);
    const funcionarios = await resposta.json();

    const lista = document.getElementById('lista');
    lista.innerHTML = '';

    funcionarios.forEach(function(f) {
        lista.innerHTML +=
            `<li>${f.nome} - ${f.funcao} - R$ ${f.salario}</li>`;
    });
}

listar();